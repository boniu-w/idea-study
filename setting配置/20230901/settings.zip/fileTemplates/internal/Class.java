#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/************************************************************************
 * author: wg
 * description: ${NAME} 
 * createTime: ${TIME} ${DATE}
 * updateTime: ${TIME} ${DATE}
 ************************************************************************/
public class ${NAME} {
}
